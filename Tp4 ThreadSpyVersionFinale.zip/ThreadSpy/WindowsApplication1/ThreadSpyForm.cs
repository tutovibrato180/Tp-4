using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace ThreadSpy
{
    public partial class ThreadSpyForm : Form
    {
        private Thread drawingThread;
        
        private ThreadStart ts;
        private int cptRun=0;
        private char c='a';
        private char[] lettres = { 'a', 'b', 'c','d','e','f','g','h','i','j','k','l','m','n','o','p','r','s','t' };
        private int cpt = 0;
        
        public ThreadSpyForm()
        {
            InitializeComponent();


            this.ts = new ThreadStart(this.Run);
            drawingThread = new Thread(ts);
        }

        /// <summary>
        /// This method is called when the user clicks the button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Run()
        {

            try {       
                for (int i = 0; i < this.cptRun; i++)
            {
                Thread.Sleep(300);
                TextBoxHelper.AddChar(this.TextBoxOutput, this.c);
            }

            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex);
            }





        }

        private void ButtonStartThread_Click(object sender, EventArgs e) 
        {
            try
            {
                string car = "";

                int i = 0;
                do
                {
                    car += c;
                    i = i + 1;
                } while (i < cpt);

                DialogResult result;
                result = MessageBox.Show("veullez appuyez sur oui pour afficher successivement 20 caractere ou non pour afficher autrement la suite", "ThreadSy Indique", MessageBoxButtons.YesNoCancel);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    this.cptRun = 20;
                    this.TextBoxOutput.Clear();
                    //this.cpt=cpt+1;
                    this.c = lettres[cpt];

                    this.ts = new ThreadStart(this.Run);
                    drawingThread = new Thread(this.ts);
                    this.cpt = cpt + 1;
                }

                else
                {
                    
                   if(this.cpt==0)
                   {
                       this.cptRun = 1;
                   }

                   else
                   {
                       this.cptRun = cpt+1;
                   }
                       
                    this.TextBoxOutput.Clear();
                    //this.cpt=cpt+1;
                    this.c = lettres[cpt];

                    this.ts = new ThreadStart(this.Run);
                    drawingThread = new Thread(this.ts);
                    this.cpt = cpt + 1;
                    
                }



                drawingThread.Start();

            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex);
            }


           // MessageBox.Show(" " + this.c + " " + this.lettres[cpt]);
            
               


           
           
        }

        /// <summary>
        /// This method is called 10 times per second by the timer 
        /// to show the current status of the thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (drawingThread != null)
                this.TextBoxStatus.Text = drawingThread.ThreadState.ToString();
            


                

        }

        private void TextBoxOutput_TextChanged(object sender, EventArgs e)
        {

        }

        private void ThreadSpyForm_Click(object sender, EventArgs e)
        {
            

        }
}
}